from flask import Flask, render_template, request, redirect, session
import os
from werkzeug.utils import secure_filename
import psycopg2

app = Flask(__name__)
app.secret_key = "secret123"

UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# ================= DB =================
def get_db():
    return psycopg2.connect(
        "postgresql://claim_db_iw7g_user:VqDnpd2yPdNqtEKGla3esCEUMlEa3Kq7@dpg-d71nmima2pns73fas9b0-a.singapore-postgres.render.com/claim_db_iw7g"
    )


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100),
        email VARCHAR(100),
        password TEXT,
        role VARCHAR(20)
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS claims (
        id SERIAL PRIMARY KEY,
        user_id INT,
        title VARCHAR(255),
        amount DECIMAL,
        category VARCHAR(100),
        status VARCHAR(20) DEFAULT 'Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        receipt VARCHAR(255)
    )
    """)

    conn.commit()
    conn.close()


# ================= LOGIN =================
@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if email == "admin@test.com" and password == "123":
            session["user_id"] = 1
            session["role"] = "admin"
            session["name"] = "Admin"
            return redirect("/admin/dashboard")

        elif email == "user@test.com" and password == "123":
            session["user_id"] = 2
            session["role"] = "user"
            session["name"] = "User"
            return redirect("/dashboard")

        else:
            return render_template("login.html", error="Invalid email or password")

    return render_template("login.html")


# ================= LOGOUT =================
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# ================= USER DASHBOARD =================
@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM claims WHERE user_id=%s", (session["user_id"],))
    total = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM claims WHERE status='Pending' AND user_id=%s", (session["user_id"],))
    pending = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM claims WHERE status='Approved' AND user_id=%s", (session["user_id"],))
    approved = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM claims WHERE status='Rejected' AND user_id=%s", (session["user_id"],))
    rejected = cur.fetchone()[0]

    cur.execute("""
        SELECT title, amount, category, status
        FROM claims
        WHERE user_id=%s
        ORDER BY created_at DESC
    """, (session["user_id"],))

    claims = cur.fetchall()
    conn.close()

    return render_template("claims_dashboard.html",
        total=total,
        pending=pending,
        approved=approved,
        rejected=rejected,
        claims=claims
    )


# ================= ADMIN DASHBOARD =================
@app.route("/admin/dashboard")
def admin_dashboard():

    if "user_id" not in session or session.get("role") != "admin":
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
    SELECT 
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status='Pending') as pending,
        COUNT(*) FILTER (WHERE status='Approved') as approved,
        COUNT(*) FILTER (WHERE status='Rejected') as rejected
    FROM claims
    """)

    stats = cur.fetchone()

    cur.execute("""
    SELECT title, category, amount AS claim_amount, status
    FROM claims
    ORDER BY created_at DESC LIMIT 5
    """)

    recent_claims = cur.fetchall()

    conn.close()

    return render_template("admin_dashboard.html",
        total_this_month=5,
        approved_leave=2,
        pending_leave=2,
        rejected_leave=1,
        recent_requests=[],
        on_leave_today=[],
        claim_total=stats[0],
        claim_pending=stats[1],
        claim_approved=stats[2],
        claim_rejected=stats[3],
        recent_claims=recent_claims,
        trend_labels=["Mon","Tue","Wed","Thu","Fri"],
        trend_data=[3,5,2,6,4]
    )


# ================= SUBMIT CLAIM =================
@app.route("/claims/submit", methods=["GET","POST"])
def submit_claim():
    if "user_id" not in session:
        return redirect("/")

    if request.method == "POST":
        title = request.form["title"]
        amount = float(request.form["amount"])
        category = request.form["category"]

        file = request.files.get("receipt")
        filename = None

        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))

        conn = get_db()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO claims (user_id,title,amount,category,receipt)
            VALUES (%s,%s,%s,%s,%s)
        """, (session["user_id"], title, amount, category, filename))

        conn.commit()
        conn.close()

        return redirect("/dashboard")

    return render_template("submit_claim.html")


# ================= ADMIN CLAIMS =================
@app.route("/admin/claims")
def admin_claims():
    if "role" not in session or session["role"] != "admin":
        return redirect("/")

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT id, title, amount, category, status
        FROM claims
        ORDER BY created_at DESC
    """)

    claims = cur.fetchall()
    conn.close()

    return render_template("admin_claims.html", claims=claims)


# ================= APPROVE =================
@app.route("/approve/<int:id>")
def approve(id):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("UPDATE claims SET status='Approved' WHERE id=%s", (id,))
    conn.commit()
    conn.close()

    return redirect("/admin/claims")


# ================= REJECT =================
@app.route("/reject/<int:id>")
def reject(id):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("UPDATE claims SET status='Rejected' WHERE id=%s", (id,))
    conn.commit()
    conn.close()

    return redirect("/admin/claims")


# ================= RUN =================
if __name__ == "__main__":
    init_db()
    app.run(debug=True)